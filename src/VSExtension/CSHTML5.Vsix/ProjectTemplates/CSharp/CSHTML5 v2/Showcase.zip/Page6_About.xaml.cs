﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;

namespace $safeprojectname$
{
    public partial class Page6_About : Page
    {
        public Page6_About()
        {
            this.InitializeComponent();
        }
    }
}
