﻿Imports System
Imports System.Collections.Generic
Imports System.IO
Imports System.Linq
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Controls.Primitives
Imports System.Windows.Data
Imports System.Windows.Input
Imports System.Windows.Media
Imports System.Windows.Navigation

Partial Public Class $safeitemname$
    Inherits Page
    Public Sub New()
        Me.InitializeComponent()
    End Sub
End Class
